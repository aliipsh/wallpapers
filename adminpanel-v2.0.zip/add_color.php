<?php include("includes/header.php");

	require("includes/function.php");
	require("language/language.php");

	require_once("thumbnail_images.class.php");

	 $cat_qry="SELECT * FROM tbl_color ORDER BY cc_name";
	$cat_result=mysqli_query($mysqli,$cat_qry); 
	
	if(isset($_POST['submit']) and isset($_GET['add']) and $_SESSION['TYPE_USERNAME']!=2)
	{
	
	   $color_image=rand(0,99999)."_".getName($n);
		 	 
       //Main Image
	   $tpath1='images/'.$color_image; 			 
       $pic1=compress_image($_FILES["cc_image"]["tmp_name"], $tpath1, 50);
	 
	  
		//Thumb Image 
	   $thumbpath='images/thumbs/'.$color_image;
	   list($width, $height) = getimagesize($tpath1);
	   
	   $newheight = round($height * (250*100/$width)/100);
	   
       $thumb_pic1=create_thumb_image($tpath1,$thumbpath,'250',$newheight);
 
          
       $data = array( 
			    'cc_name'  =>  $_POST['cc_name'],
			    'cc_image'  =>  $color_image,
  				'cc_status'  =>  1
			    );		

 		$qry = Insert('tbl_color',$data);	

 	   
		$_SESSION['msg']="10"; 
		header( "Location:manage_color.php");
		exit;	

		 
		
	}
	
	if(isset($_GET['cc_id']))
	{
			 
			$qry="SELECT * FROM tbl_color where cc_id='".$_GET['cc_id']."'";
			$result=mysqli_query($mysqli,$qry);
			$row=mysqli_fetch_assoc($result);

	}
	
	if($_SESSION['TYPE_USERNAME']==2){
	    ?>
	    <script type="text/javascript">
    
            // Written using ES5 JS for browser support
            window.addEventListener('DOMContentLoaded', function () {
            	// Form elements
            		var title = 'Notification';
            		var message = 'In Mode Preview some process doesnt execute!';
            		var position = 'nfc-bottom-left';
            		var duration = '5000';
            		var theme = 'error';
            		var closeOnClick = false;
            		var displayClose = true;
            
            		if(!message) {
            			message = 'You did not enter a message...';
            		}
            
            		window.createNotification({
            			closeOnClick: closeOnClick,
            			displayCloseButton: displayClose,
            			positionClass: position,
            			showDuration: duration,
            			theme: theme
            		})({
            			title: title,
            			message: message
            		});
            });

        </script>
	    <?php
	}
	if(isset($_POST['submit']) and isset($_POST['cc_id']) and $_SESSION['TYPE_USERNAME']!=2)
	{
		 
		 if($_FILES['cc_image']['name']!="")
		 {		


				$img_res=mysqli_query($mysqli,'SELECT * FROM tbl_color WHERE cc_id='.$_GET['cc_id'].'');
			    $img_res_row=mysqli_fetch_assoc($img_res);
			

			    if($img_res_row['cc_image']!="")
		        {
					unlink('images/thumbs/'.$img_res_row['cc_image']);
					unlink('images/'.$img_res_row['cc_image']);
			     }

 				   $cc_image=rand(0,99999)."_".getName($n);
		 	 
			       //Main Image
				   $tpath1='images/'.$cc_image; 			 
			       $pic1=compress_image($_FILES["cc_image"]["tmp_name"], $tpath1, 50);
				 
					//Thumb Image 
				   $thumbpath='images/thumbs/'.$cc_image;
	               list($width, $height) = getimagesize($tpath1);
	   
	               $newheight = round($height * (250*100/$width)/100);
	   
                   $thumb_pic1=create_thumb_image($tpath1,$thumbpath,'250',$newheight);	

                    $data = array(
					
					     'cc_name'  =>  $_POST['cc_name'],
			            'cc_image'  =>  $cc_image,
					   
						);

					$category_edit=Update('tbl_color', $data, "WHERE cc_id = '".$_POST['cc_id']."'");

		 }
		 else
		 {

					 $data = array(
			           'cc_name'  =>  $_POST['cc_name'],

						);	
 
			         $category_edit=Update('tbl_color', $data, "WHERE cc_id = '".$_POST['cc_id']."'");

		 }

		     
		$_SESSION['msg']="11"; 
		header( "Location:manage_color.php");
		exit;
 
	}


?>
<div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="page_title_block">
            <div class="col-md-5 col-xs-12">
              <div class="page_title"><?php if(isset($_GET['cc_id'])){?>Edit<?php }else{?>Add<?php }?> Color</div>
            </div>
          </div>
          <div class="clearfix"></div>
          <div class="row mrg-top">
            <div class="col-md-12">
               
              <div class="col-md-12 col-sm-12">
                <?php if(isset($_SESSION['msg'])){?> 
               	 <div class="alert alert-success alert-dismissible" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
                	<?php echo $client_lang[$_SESSION['msg']] ; ?></a> </div>
                <?php unset($_SESSION['msg']);}?>	
              </div>
            </div>
          </div>
          <div class="card-body mrg_bottom"> 
            <form action="" name="addeditcategory" method="post" class="form form-horizontal" enctype="multipart/form-data">
            	<input  type="hidden" name="cc_id" value="<?php echo $_GET['cc_id'];?>" />

              <div class="section">
                <div class="section-body">
			
			
                  <div class="form-group">
                    <label class="col-md-3 control-label">Color Name :-</label>
                    <div class="col-md-6">
                      <input type="text" name="cc_name" id="cc_name" value="<?php if(isset($_GET['cc_id'])){echo $row['cc_name'];}?>" class="form-control" required>
                    </div>
                  </div>     
                  
                    <div class="form-group">
                    <label class="col-md-3 control-label"> Color Image :-</label>
                    <div class="col-md-6">
                      <div class="fileupload_block">
                        <input type="file" name="cc_image" value="fileupload" id="fileupload"  <?php if(!isset($_GET['cc_id'])) {?>required<?php }?>>
                            <?php if(isset($_GET['cc_id']) and $row['cc_image']!="") {?>
                        	  <div class="fileupload_img"><img type="image" src="images/<?php echo $row['cc_image'];?>" alt="color image" style="width: 172px;"/></div>
                        	<?php } else {?>
                        	  <div class="fileupload_img"><img type="image" src="assets/images/add-image.png" alt="banner image" /></div>
                        	<?php }?>
                      </div>
                    </div>
                  </div>
            
             
                  <div class="form-group">
                    <div class="col-md-9 col-md-offset-3">
                      <button type="submit" name="submit" class="btn btn-primary">Save</button>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
        
<?php include("includes/footer.php");?>       
