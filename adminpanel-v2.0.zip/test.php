<?php

 

$to = 'nakumkuldip@gmail.com';
			// subject
			$subject = '[IMPORTANT] test subject';
 			
			$message='test';
 
			 
		//	$headers = 'MIME-Version: 1.0' . "\r\n";
			//$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
			$headers .= 'From:support@kingdov.net' . "\r\n";
			 
			mail($to, $subject, $message, $headers);
			
			echo "send";
			
			?>
			
