<?php

	require_once("Rest.inc.php");
	require_once("db.php");
	require_once("functions.php");

	class API extends REST {

		private $functions = NULL;
		private $db = NULL;

		public function __construct() {
			$this->db = new DB();
			$this->functions = new functions($this->db);
		//$this->mysqli->query('SET CHARACTER SET utf8mb4');
		}

		public function check_connection() {
			$this->functions->checkConnection();
		}

		/*
		 * ALL API Related android client -------------------------------------------------------------------------
		*/

	private function get_color_details() {
	        $this->functions->getColorDetails();
	    }


	private function get_image_by_color_id() {
	        $this->functions->getImageByColorId();
	    }

		private function get_app_details() {
	        $this->functions->getAppDetails();
	    }

	   private function post_user_social_login() {
	        $this->functions->postUserSocialLogin();
	    }
	    
	    private function post_user_email_login() {
	        $this->functions->postUseremailLogin();
	    }
	    

       private function email_login() {
	        $this->functions->emaillogin();
	    }
	    
        private function post_user_status() {
	        $this->functions->postuserstatus();
	    }

        private function get_user_profile() {
	        $this->functions->getUserProfile();
	    }

	    private function post_user_profile_update() {
	        $this->functions->postUserProfileUpdate();
	    }

        //image
		 private function get_img_cat() {
	        $this->functions->getImageCategory();
	    }
		
		private function get_featured_img_cat() {
	        $this->functions->getfeaturedImageCategory();
	    }
		
		//start
		private function get_img_list() {
	        $this->functions->getImageList();
	    }
	    
	    private function get_home_img_list() {
	        $this->functions->gethomeImageList();
	    }
	    
	       private function get_home_img_list_recent() {
	        $this->functions->gethomeImageListrecent();
	    }
	    
	    
	       private function get_home_img_list_popular() {
	        $this->functions->gethomeImageListpopular();
	    }
	    
	      private function get_tredning_img_list() {
	        $this->functions->gettredningImageList();
	    }	
		
			private function get_img_search() {
	        $this->functions->getImagesearch();
	    }
//end

	   // live wallpaper
	   

	      private function get_trending_gif_List(){
	        $this->functions->gettrendinggifList();
	    } 
	    
	      private function get_home_gif_List(){
	        $this->functions->gethomgifList();
	    } 
	    

        
	     private function image_upload(){
	        $this->functions->imageupload();
	    } 
	    
        private function wallpaper_download_count() {
	        $this->functions->wallpaper_download_count();
	    }
	    
	       private function ringtone_download_count() {
	        $this->functions->ringtone_download_count();
	    }
	    
	    
	      
	    private function get_trending_user() {
	        $this->functions->gettrendinguser();
	    }
	    
	    
	    private function get_user_wallpaper() {
	        $this->functions->getuserwallpaper();
	    }
	    
	     
	     
	      private function get_All_notification() {
	        $this->functions->getAllnotification();
	    }
	     
		/*
		 * End of API Transactions ----------------------------------------------------------------------------------
		*/

		public function processApi() {
			if(isset($_REQUEST['x']) && $_REQUEST['x']!=""){
				$func = strtolower(trim(str_replace("/","", $_REQUEST['x'])));
				if((int)method_exists($this,$func) > 0) {
					$this->$func();
				} else {
					echo 'processApi - method not exist';
					exit;
				}
			} else {
				echo 'processApi - method not exist';
				exit;
			}
		}

	}

	// Initiiate Library
	$api = new API;
	$api->processApi();

?>
