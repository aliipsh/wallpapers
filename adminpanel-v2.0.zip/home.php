<?php include("includes/header.php");

$qry_cat="SELECT COUNT(*) as num FROM tbl_img_cat";
$totalimagecat= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat));
$totalimagecat = $totalimagecat['num'];

$qry_colors="SELECT COUNT(*) as num FROM tbl_color";
$totalimagecolors= mysqli_fetch_array(mysqli_query($mysqli,$qry_colors));
$totalimagecolors = $totalimagecolors['num'];

$qry_video="SELECT COUNT(*) as num FROM tbl_status_cat";
$totalstatuscat = mysqli_fetch_array(mysqli_query($mysqli,$qry_video));
$totalstatuscat = $totalstatuscat['num'];


$qry_users="SELECT COUNT(*) as num FROM tbl_video_cat";
$totalvideocat = mysqli_fetch_array(mysqli_query($mysqli,$qry_users));
$totalvideocat = $totalvideocat['num'];

$qry_cat1="SELECT COUNT(*) as num FROM tbl_img_list WHERE status=1";
$totalimglist= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat1));
$totalimglist = $totalimglist['num'];

$qry_video1="SELECT COUNT(*) as num FROM tbl_status_list";
$totalstatuslist = mysqli_fetch_array(mysqli_query($mysqli,$qry_video1));
$totalstatuslist = $totalstatuslist['num'];


$qry_users1="SELECT COUNT(*) as num FROM tbl_video WHERE status=1";
$totalvideolist = mysqli_fetch_array(mysqli_query($mysqli,$qry_users1));
$totalvideolist = $totalvideolist['num'];


$qry_gif2="SELECT COUNT(*) as num FROM tbl_gif_list";
$totalvideolist2 = mysqli_fetch_array(mysqli_query($mysqli,$qry_gif2));
$totalgiflist = $totalvideolist2['num'];

$qry_cat2="SELECT COUNT(*) as num FROM tbl_img_list WHERE status=0";
$totalimglist2= mysqli_fetch_array(mysqli_query($mysqli,$qry_cat2));
$totalunimglist2 = $totalimglist2['num'];
 
$qry_users2="SELECT COUNT(*) as num FROM tbl_video WHERE status=0";
$totalvideolist2 = mysqli_fetch_array(mysqli_query($mysqli,$qry_users2));
$totalunvideolist2 = $totalvideolist2['num'];
 
 
 
 
 
$tbl_ringtone_cat="SELECT COUNT(*) as num FROM tbl_ringtone_cat WHERE status=1";
$tbl_ringtone_cat1 = mysqli_fetch_array(mysqli_query($mysqli,$tbl_ringtone_cat));
$tbl_ringtone_cat2 = $tbl_ringtone_cat1['num'];
  
 $tbl_ringtone="SELECT COUNT(*) as num FROM tbl_ringtone WHERE status=1";
$tbl_ringtone1 = mysqli_fetch_array(mysqli_query($mysqli,$tbl_ringtone));
$tbl_ringtone2 = $tbl_ringtone1['num'];
  
 $tbl_ringtone0="SELECT COUNT(*) as num FROM tbl_ringtone WHERE status=0";
$tbl_ringtone01 = mysqli_fetch_array(mysqli_query($mysqli,$tbl_ringtone0));
$tbl_ringtone02 = $tbl_ringtone01['num'];

 $tbl_users="SELECT COUNT(*) as num FROM tbl_users WHERE status=1";
$tbl_users = mysqli_fetch_array(mysqli_query($mysqli,$tbl_users));
$tbl_users = $tbl_users['num'];

?>       


	
<div class="row">
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 bg-primary widget-chart text-white card-border">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-sitemap text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalimagecat;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Total Categories</div>
            <div class="widget-description  text-white">
                 <a class="badg" href="manage_img_category.php"><i class="fa fa-angle-up ">

                </i>
                <span class="pl-1">GO</span></a></div>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 bg-success widget-chart text-white card-border">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-image text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalimglist;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Wallpapers Total</div>
            <div class="widget-description  text-white">
                 <a class="badg" href="manage_img_list.php"><i class="fa fa-angle-up ">

                </i>
                <span class="pl-1">GO</span></a></div>
        </div>
    </div>
    
    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-3 bg-warning widget-chart text-white card-border">
            <div class="icon-wrapper rounded-circle">
                <div class="icon-wrapper-bg bg-white opacity-1"></div>
                <i class="fa fa-check-square-o text-white"></i></div>
            <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalunimglist2;?>" data-speed="2000" >0</div>
            <div class="widget-subheading">Unapprove Wallpapers</div>
            <div class="widget-description  text-white">
                 <a class="badg" href="manage_img_approval.php"><i class="fa fa-angle-up ">

                </i>
                <span class="pl-1">GO</span></a></div>
        </div>
    </div>
      
    

        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 bg-focus widget-chart text-white card-border">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-paint-brush text-white"></i></div>
                <div class="widget-numbers timer" data-from="0" data-to="<?php echo $totalimagecolors;?>" data-speed="2000" >0</div>
                <div class="widget-subheading">Colors Total</div>
                <div class="widget-description  text-white">
                     <a class="badg" href="manage_color.php"><i class="fa fa-angle-up ">
    
                    </i>
                    <span class="pl-1">GO</span></a></div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 bg-danger widget-chart text-white card-border">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-film text-white"></i></div>
                <div class="timer widget-numbers" data-from="0" data-to="<?php echo $totalgiflist;?>" data-speed="2000" >0</div>
                <div class="widget-subheading">Live Wallpaper</div>
                <div class="widget-description  text-white">
                     <a class="badg" href="manage_gif_list.php"><i class="fa fa-angle-up ">
    
                    </i>
                    <span class="pl-1">GO</span></a></div>
            </div>
        </div>
        
        <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
            <div class="card mb-3 bg-info widget-chart text-white card-border">
                <div class="icon-wrapper rounded-circle">
                    <div class="icon-wrapper-bg bg-white opacity-1"></div>
                    <i class="fa fa-user text-white"></i></div>
                <div id="timer" class="widget-numbers timer" data-from="0" data-to="<?php echo $tbl_users;?>" data-speed="2000" data-refresh-interval="5">0</div>
                <div class="widget-subheading">Number Of Users</div>
                <div class="widget-description  text-white">
                     <a class="badg" href="manage_users.php"><i class="fa fa-angle-up ">
    
                    </i>
                    <span class="pl-1">GO</span></a></div>
            </div>
        </div>
        
        
	<!--   <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"> <a href="manage_gif_list.php" class="card card-banner card-yellow-light">-->
 <!--       <div class="card-body"> <i class="icon fa fa-users fa-4x"></i>-->
 <!--         <div class="content">-->
 <!--           <div class="title">live wallpaper</div>-->
 <!--           <div class="value"><span class="sign"></span>
 <!--<?php echo $totalgiflist;?></div>-->
 <!--         </div>-->
 <!--       </div>-->
 <!--       </a> -->
	<!--</div> -->
	
	<!-- <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12"> <a href="manage_users.php" class="card card-banner card-yellow-light">-->
 <!--       <div class="card-body"> <i class="icon fa fa-users fa-4x"></i>-->
 <!--         <div class="content">-->
 <!--           <div class="title">user</div>-->
 <!--           <div class="value"><span class="sign"></span>
 <!--<?php  echo $tbl_users;?></div>-->
 <!--         </div>-->
 <!--       </div>-->
 <!--       </a> -->
	<!--</div> -->
      	</div>   
<?php include("includes/footer.php");?>       

 <script type="text/javascript">
  $('.timer').countTo();
</script>